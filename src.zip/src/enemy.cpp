#include "enemy.h"
#include <godot_cpp/classes/resource_loader.hpp>

#include "quat_camera.h"


using namespace godot;

void Enemy::_bind_methods() {}

Enemy::Enemy() {}

Enemy::~Enemy() {}

//pass a pointer to the player object to this enemy
void Enemy::_process(double delta){

}


#ifndef DEFS_H
#define DEFS_H

// easily toggle off the debug messages in the entire library
#define DEBUG true

//Player Control Values
#define CAMERA_SENS 0.005

// add some of your own constants here :)

#endif // DEFS_H